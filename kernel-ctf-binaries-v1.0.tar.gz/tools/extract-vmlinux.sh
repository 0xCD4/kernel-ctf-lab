#!/bin/bash
#
# extract-vmlinux.sh — Extract vmlinux ELF from compressed bzImage
#
# Usage: ./extract-vmlinux.sh <bzImage> > vmlinux
#
# After extraction:
#   ROPgadget --binary vmlinux --only "pop|ret|mov|swapgs" > gadgets.txt
#   nm vmlinux | grep -E "prepare_kernel_cred|commit_creds|modprobe_path"
#
set -e

BZIMAGE="${1:?Usage: $0 <bzImage>}"

if [ ! -f "$BZIMAGE" ]; then
    echo "File not found: $BZIMAGE" >&2
    exit 1
fi

# Search for gzip/xz/bzip2/lzma/lzo/lz4/zstd compressed ELF inside bzImage
for pos in $(tr '\000\037\213\010' '\n=\n=' < "$BZIMAGE" | grep -abo '=' | sed 's/=//'); do
    if dd if="$BZIMAGE" bs=1 skip=$((pos - 1)) 2>/dev/null | \
       file - | grep -q gzip; then
        dd if="$BZIMAGE" bs=1 skip=$((pos - 1)) 2>/dev/null | \
        gunzip 2>/dev/null
        exit 0
    fi
done

# Try alternative magic bytes
for byte in '\x1f\x8b\x08' '\xfd\x37\x7a\x58\x5a' '\x89\x4c\x5a\x4f' '\x02\x21\x4c\x18' '\x28\xb5\x2f\xfd'; do
    pos=$(grep -aboPm1 "$byte" "$BZIMAGE" 2>/dev/null | head -1 | cut -d: -f1) || true
    if [ -n "$pos" ]; then
        tail -c+$((pos + 1)) "$BZIMAGE" | unlz4 2>/dev/null || \
        tail -c+$((pos + 1)) "$BZIMAGE" | unxz 2>/dev/null || \
        tail -c+$((pos + 1)) "$BZIMAGE" | unlzma 2>/dev/null || \
        tail -c+$((pos + 1)) "$BZIMAGE" | bunzip2 2>/dev/null || \
        tail -c+$((pos + 1)) "$BZIMAGE" | unzstd 2>/dev/null || true
        if [ ${PIPESTATUS[1]}  -eq 0 ]; then exit 0; fi
    fi
done

echo "Could not extract vmlinux from $BZIMAGE" >&2
echo "Try using the kernel source tree's scripts/extract-vmlinux instead." >&2
exit 1
